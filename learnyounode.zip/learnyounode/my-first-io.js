const fs = require('fs');
const { stdout } = require('process');

var filepath = process.argv[2].toString();

const file = fs.readFileSync(filepath).toString();

var nLines = (file.split('\n')).length;

console.log(nLines-1);







