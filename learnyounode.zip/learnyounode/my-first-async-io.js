const fs = require('fs');

var path = process.argv[2].toString();

fs.readFile(path,'utf-8',(err, fileCont)=>{
    if(err){
        console.log('Reading Failed',err)
        return
    }

    var nLines = fileCont.split('\n').length

    console.log(nLines-1)
})

